package tutorial.form;

public class ConditionForm {

	public String id;
}
