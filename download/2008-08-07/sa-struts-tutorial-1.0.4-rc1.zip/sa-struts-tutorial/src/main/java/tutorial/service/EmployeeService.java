package tutorial.service;

import tutorial.entity.Employee;

public class EmployeeService extends AbstractService<Employee> {

}
