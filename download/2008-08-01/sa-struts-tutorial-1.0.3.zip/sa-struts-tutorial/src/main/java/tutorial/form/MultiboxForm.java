package tutorial.form;

public class MultiboxForm {

	public String[] checks = new String[0];

	public void initialize() {
		checks = new String[] { "Check1" };
	}
}