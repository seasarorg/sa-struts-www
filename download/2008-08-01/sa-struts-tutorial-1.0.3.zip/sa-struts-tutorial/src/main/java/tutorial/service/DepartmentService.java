package tutorial.service;

import tutorial.entity.Department;

public class DepartmentService extends AbstractService<Department> {

}
