package tutorial.form;

public class TilesForm {

	public String name = "Seasar2";
}
