package tutorial.form;

public class CheckboxForm {

	public boolean check1;

	public boolean check2;

	public void initialize() {
		check2 = true;
	}
}
