/**
 * SAStrutsのユーティリティに関する機能を提供します。
 */
package org.seasar.struts.util;