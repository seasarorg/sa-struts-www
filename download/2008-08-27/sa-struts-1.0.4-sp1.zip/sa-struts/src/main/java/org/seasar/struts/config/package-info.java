/**
 * SAStruts用の設定に関する機能を提供します。
 */
package org.seasar.struts.config;