package tutorial.form;

public class TextareaForm {

	public String textarea;

	public void initialize() {
		textarea = "initial value";
	}
}