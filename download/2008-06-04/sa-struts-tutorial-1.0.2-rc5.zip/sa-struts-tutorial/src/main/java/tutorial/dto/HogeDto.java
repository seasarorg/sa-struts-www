package tutorial.dto;

public class HogeDto {

	public String aaa;
}
