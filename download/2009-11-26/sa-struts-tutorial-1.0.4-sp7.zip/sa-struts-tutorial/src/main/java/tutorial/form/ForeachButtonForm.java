package tutorial.form;

public class ForeachButtonForm {

	public String id;
}