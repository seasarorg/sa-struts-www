package tutorial.form;

public class SelectForm {

	public String select;

	public void initialize() {
		select = "3";
	}
}