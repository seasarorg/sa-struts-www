package tutorial.form;

public class ForeachForm {

	public String id;
}