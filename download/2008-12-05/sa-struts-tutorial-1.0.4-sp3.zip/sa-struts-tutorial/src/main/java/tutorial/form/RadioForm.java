package tutorial.form;

public class RadioForm {

	public String radio;

	public void initialize() {
		radio = "3";
	}
}