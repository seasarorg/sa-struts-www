/**
 * SAStruts用のActionに関する機能を提供します。
 */
package org.seasar.struts.action;